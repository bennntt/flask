from flask import Flask
from config import Config

def create_app(config_class=Config):
    app = Flask(__name__, static_folder='static')
    app.config.from_object(config_class)

    # استيراد Blueprints من ملف routes/__init__.py
    from app.routes import shop_bp, buyer_bp, tips_bp, trends_bp, niche_bp
    from app.routes.seo import bp as seo_bp
    from app.routes.listing import bp as listing_bp
    app.register_blueprint(listing_bp)
    app.register_blueprint(seo_bp)
    app.register_blueprint(shop_bp)
    app.register_blueprint(buyer_bp)
    app.register_blueprint(tips_bp)
    app.register_blueprint(trends_bp)
    app.register_blueprint(niche_bp)

    return app