from flask import Blueprint, render_template

bp = Blueprint('tips', __name__, url_prefix='/brainstorm')

@bp.route('/etsy-tips')
def etsy_tips():
    return render_template('tips_for_selling.html', active_section='Etsy Tips')