# هذا الملف يجب أن يكون فارغاً أو يحوي استيرادات فقط
from .shop import bp as shop_bp
from .buyer import bp as buyer_bp
from .tips import bp as tips_bp
from .trends import bp as trends_bp
from .niche_finder import bp as niche_bp

__all__ = ['shop_bp', 'buyer_bp', 'tips_bp', 'trends_bp', 'niche_bp']