from flask import Blueprint, render_template

bp = Blueprint('buyer', __name__, url_prefix='/shop')

@bp.route('/buyer-check')
def buyer_check():
    return render_template('shop/buyer_check.html', active_section='Buyer Check')