from flask import Blueprint, render_template

bp = Blueprint('niche', __name__, url_prefix='/brainstorm')

@bp.route('/niche-finder')
def niche_finder():
    return render_template('niche_finder.html', active_section='Niche Finder')