from flask import Blueprint, render_template, request

bp = Blueprint('shop', __name__, url_prefix='/shop')


@bp.route('/shop-analyzer', methods=['GET', 'POST'])
def shop_analyzer():
    shop_name = ''
    searched_shop = ''

    if request.method == 'POST':
        shop_name = request.form.get('shop_name', '').strip()
        if shop_name:
            searched_shop = shop_name

    return render_template(
        'shop/shop_analyzer.html',
        active_section='Shop Analyzer',
        shop_name=shop_name,
        searched_shop=searched_shop
    )