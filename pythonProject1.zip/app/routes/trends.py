from flask import Blueprint, render_template

bp = Blueprint('trends', __name__, url_prefix='/brainstorm')

@bp.route('/etsy-trends')
def etsy_trends():
    return render_template('etsy_trends.html', active_section='Etsy Trends')