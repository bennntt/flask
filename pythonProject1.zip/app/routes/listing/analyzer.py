from flask import render_template, request
from app.routes.listing import bp

@bp.route('/analyzer', methods=['GET', 'POST'])
def listing_analyzer():
    if request.method == 'POST':
        listing_url = request.form.get('listing_url', '').strip()
        if listing_url:
            return render_template('listing/analyzer.html',
                                   listing_url=listing_url,
                                   active_section='Listing Analyzer')

    return render_template('listing/analyzer.html',
                           active_section='Listing Analyzer')