from flask import render_template, request
from app.routes.listing import bp

@bp.route('/profit-calculator', methods=['GET', 'POST'])
def profit_calculator():
    if request.method == 'POST':
        price = float(request.form.get('price', 0))
        cost = float(request.form.get('cost', 0))
        fee = float(request.form.get('fee', 0))
        profit = price - cost - fee

        return render_template('listing/profit.html',
                               price=price,
                               cost=cost,
                               fee=fee,
                               profit=profit,
                               active_section='Profit Calculator')

    return render_template('listing/profit.html',
                           active_section='Profit Calculator')