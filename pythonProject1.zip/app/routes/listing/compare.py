from flask import render_template, request
from app.routes.listing import bp

@bp.route('/compare', methods=['GET', 'POST'])
def compare_listings():
    if request.method == 'POST':
        listing1 = request.form.get('listing1', '').strip()
        listing2 = request.form.get('listing2', '').strip()
        if listing1 and listing2:
            return render_template('listing/compare.html',
                                   listing1=listing1,
                                   listing2=listing2,
                                   active_section='Compare Listings')

    return render_template('listing/compare.html',
                           active_section='Compare Listings')