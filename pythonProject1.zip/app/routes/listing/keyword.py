from flask import render_template, request
from app.routes.listing import bp

@bp.route('/keyword-trend', methods=['GET', 'POST'])
def keyword_trend():
    if request.method == 'POST':
        keyword = request.form.get('keyword', '').strip()
        if keyword:
            return render_template('listing/keyword.html',
                                   keyword=keyword,
                                   active_section='Keyword Trend')

    return render_template('listing/keyword.html',
                           active_section='Keyword Trend')