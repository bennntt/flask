from flask import Blueprint, render_template

bp = Blueprint('seo', __name__, url_prefix='/seo-tools')

@bp.route('/title-generator')
def title_generator():
    return render_template('seo/title_generator.html', active_section='Title Generator')

@bp.route('/description-generator')
def description_generator():
    return render_template('seo/description_generator.html', active_section='Description Generator')

@bp.route('/tag-generator')
def tag_generator():
    return render_template('seo/tag_generator.html', active_section='Tag Generator')

@bp.route('/rank-check')
def rank_check():
    return render_template('seo/rank_check.html', active_section='Rank Check')